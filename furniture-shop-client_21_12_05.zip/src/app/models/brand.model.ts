export class Brand {
    id:number;
    brand_Code: string;
    brand_Name: string;
    status: boolean; 
}