export class Category {
    id:number;
    category_Code: string;
    category_Name: string;
    status: boolean; 
}