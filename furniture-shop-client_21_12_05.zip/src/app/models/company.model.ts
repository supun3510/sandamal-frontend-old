export class Company {
    id:number;
    company_Name: string;
    contact_No: number;
    status: boolean; 
}