export class Product {
    id:number;
    brand_Id: number;
    category_Id: number;
    company_Id: number;
    itemCode: string;
    itemName: string;
    retail_Price: number;
    buy_Price: number;
    status: boolean; 
}