export class ProductionCart {
    item_Name:string;
    retail_Price: number;
    discount: number;
    quantity: number;
    discounted: number
    total_Amount: number;
}