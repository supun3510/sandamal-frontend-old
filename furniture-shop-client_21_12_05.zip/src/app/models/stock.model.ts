export class Stock {
    id: number;
    itemCode: string;
    itemName: string;
    quantity: number;
}