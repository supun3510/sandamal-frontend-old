export const environment = {
  production: true,
  baseUrl:'http://supunsam-001-site1.btempurl.com/api/'
};
